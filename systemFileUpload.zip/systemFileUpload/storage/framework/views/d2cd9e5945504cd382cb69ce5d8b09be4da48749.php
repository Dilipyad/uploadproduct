
  <div class="container">    
     <br />
     <h3 align="center">Import Export Data in CSV File</h3>
     <br />
     <div class="panel panel-default">
          <div class="panel-heading">
           <h3 class="panel-title">Import Export Data in CSV File</h3>
          </div>
          <div class="panel-body">
           <form action="<?php echo e(route('import')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="file" name="file" accept=".csv">
                  <br>
                  <button class="btn btn-success">Import User Data</button>
                  <a class="btn btn-warning" href="<?php echo e(route('export')); ?>">Export User Data</a>
                  <a class="btn btn-primary" href="<?php echo e(route('download')); ?>">Sample csv file download product</a>
           </form>
              <?php echo $__env->yieldContent('csv_data'); ?>
          </div>
      </div>
  </div>
 
<?php /**PATH /home/cloudlity/Desktop/systemFileUpload/resources/views/csv_file.blade.php ENDPATH**/ ?>