<?php $__env->startSection('csv_data'); ?>

<table class="table table-bordered table-striped">
 <thead>
  <tr>
   <th>Product Name</th>
   <th>Detail</th>
  </tr>
 </thead>
 <tbody>
 <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
   <td><?php echo e($row->name); ?></td>
   <td><?php echo e($row->detail); ?></td>
  </tr>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </tbody>
</table>

<?php echo $data->links(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('csv_file', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cloudlity/Desktop/systemFileUpload/resources/views/csv_file_pagination.blade.php ENDPATH**/ ?>